package com.udacity.sandwichclub.utils;

import android.util.Log;

import com.udacity.sandwichclub.model.Sandwich;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonUtils {

    public static Sandwich parseSandwichJson(String json) {
        // create a sandwich object
        Sandwich sandwich = new Sandwich();
        //populate this sandwich object next
        String sName;
        List<String> sAlsoKnownAs = new ArrayList<>();
        String sPlaceOfOrigin;
        String sImage;
        String sDescription;
        List<String> sIngredients = new ArrayList<>();

        //parse the json
        if (json != null) {
            try {
                JSONObject sandwichJson = new JSONObject(json);
                JSONObject nameObject = sandwichJson.getJSONObject("name");
                sName = nameObject.getString("mainName");
                Log.i("parseSandwichJSon", sName);
                JSONArray jsonArrayAlsoKnownAs = nameObject.getJSONArray("alsoKnownAs");
                if(jsonArrayAlsoKnownAs.length()>0) {
                    for (int i = 0; i < jsonArrayAlsoKnownAs.length(); i++) {
                        sAlsoKnownAs.add(jsonArrayAlsoKnownAs.getString(i));
                        Log.i("parseSandwichJSon", sAlsoKnownAs.get(i));
                    }
                }
                    sandwich.setAlsoKnownAs(sAlsoKnownAs);
                sPlaceOfOrigin = sandwichJson.getString("placeOfOrigin");
                sDescription = sandwichJson.getString("description");
                sImage = sandwichJson.getString("image");
                Log.i("parseSandwichJSon", "getting ingredients");
                JSONArray jsonArrayIngredients = sandwichJson.getJSONArray("ingredients");
                if(jsonArrayIngredients.length()>0) {
                    Log.i("parseSandwichJSon", "got ingredients");
                    for (int i = 0; i < jsonArrayIngredients.length(); i++) {
                        Log.i("parseSandwichJSon", jsonArrayIngredients.getString(i));
                        sIngredients.add(jsonArrayIngredients.getString(i));
                    }
                }
                    sandwich.setIngredients(sIngredients);

                // populate the sandwich object with the parsed values
                sandwich.setMainName(sName);

                sandwich.setPlaceOfOrigin(sPlaceOfOrigin);
                sandwich.setDescription(sDescription);
                sandwich.setImage(sImage);


            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

            return sandwich;
        }
    }

